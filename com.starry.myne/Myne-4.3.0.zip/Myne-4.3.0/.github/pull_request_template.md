Please go the the `Preview` tab and select the appropriate sub-template:
- [General PR](?expand=1&template=general_template.md): for all other PRs, including bug fixes, adding features etc.
- [Translation PR](?expand=1&template=translations_template.md): specifically to be used for translation PRs