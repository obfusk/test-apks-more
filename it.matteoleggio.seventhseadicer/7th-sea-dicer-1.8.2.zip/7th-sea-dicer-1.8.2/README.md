7th Sea Dicer is a fork of Privacy Friendly Dicer, which is a very simple dicing application. This fork is aimed at 7th sea players and it can be used to roll virtually any amount of dice. This can be done either by pressing a button or by shaking the smartphone.

<a href='https://play.google.com/store/apps/details?id=it.matteoleggio.seventhseadicer&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/></a>

This app is optimized regarding the user's privacy. It doesn't use any tracking mechanisms, neither it displays any advertisement.

It only uses one permission: Vibration for providing feedback whether dice were rolled or not. But this can be switched on/off in the settings. If the permission is not granted in Android versions higher than 6 the device simply does not vibrate.  <br />
Privacy Friendly Dicer uses SecureRandom [http://docs.oracle.com/javase/7/docs/api/java/security/SecureRandom.html] to get a number between 1 and 6 to determine the dicing result.

### Fork Additions

- Automatic success calculator based on difficulty cap
- Ability to reroll single dice
- Possibility to count sum of 15 as a double success

## Contributors

Fork:
ZenT3600

App-Icons:
Markus Hau

Github-Users: <br />
Yonjuni <br />
