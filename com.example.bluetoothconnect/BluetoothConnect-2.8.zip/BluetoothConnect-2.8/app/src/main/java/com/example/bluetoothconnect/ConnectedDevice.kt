package com.example.bluetoothconnect

import android.bluetooth.BluetoothDevice

class ConnectedDevice {
   companion object{
       var device : BluetoothDevice? = null
   }
}